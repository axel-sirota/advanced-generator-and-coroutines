from .mybomb import MyBomb
from .mybombgenerator import mybomb
from .mybomblazy import MyNotLazyBomb, mylazygenerator
from .demo import *
